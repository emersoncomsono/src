<?php
date_default_timezone_set("America/Sao_Paulo");

use Zanzara\Zanzara;
use Zanzara\Config;
use Zanzara\Context;

include(__DIR__ . "/ApiBoraFarma.php");
include(__DIR__ . "/CBot.php");
require __DIR__ . '/lib/vendor/autoload.php';

$bot = new Bot(0);
$token = $bot->getTokenBot();

$config = new Config();
$config->setParseMode(Config::PARSE_MODE_HTML);
$config->setCacheTtl(240);
$config->setConnectorOptions(['dns' => '8.8.8.8']);

$bot = new Zanzara($token, $config);

include __DIR__ . '/bot.php';

$bot->onException(function(Context $ctx, $exception) {
	echo "Erro\n";
	echo $exception;
});

$bot->run();