<?php

declare(strict_types=1);

namespace Zanzara\Telegram\Type;

/**
 *
 */
class EditedMessage extends Message
{

}
