<?php

declare(strict_types=1);

namespace Zanzara\UpdateMode;

/**
 *
 */
interface UpdateModeInterface
{

    /**
     *
     * @return void
     */
    function run(): void;

}
