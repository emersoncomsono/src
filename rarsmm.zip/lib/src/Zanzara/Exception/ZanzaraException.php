<?php

declare(strict_types=1);

namespace Zanzara\Exception;

use Exception;

/**
 * Class ZanzaraException
 * @package Zanzara\Exception
 */
class ZanzaraException extends Exception
{

}