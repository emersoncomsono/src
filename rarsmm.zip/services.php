<?php

include(__DIR__ . "/ApiBoraFarma.php");
date_default_timezone_set("America/Sao_Paulo");
echo "Looping iniciado >_" . PHP_EOL . PHP_EOL;

while (true) {
  $file = file_get_contents(__DIR__ . "/services.json");
  $file = json_decode($file, 1);

	$api = new Api();
	$data = $api->services();
	
	if($file !== $data) {
		$json = json_encode($data, JSON_PRETTY_PRINT);
		if (file_put_contents(__DIR__ . '/services.json', $json)) {
			echo "Lista atualizada - ".date('d/m/Y')." às ".date("H:i:s") . PHP_EOL;
		} else {
			echo "Erro ao atualizar a nova lista".date('d/m/Y')." às ".date("H:i:s") . PHP_EOL;
		}
	}
}